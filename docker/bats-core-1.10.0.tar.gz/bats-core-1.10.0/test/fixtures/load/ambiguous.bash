# Helper to detect regressions in load's lookup ordering.
# An exact name match should be prioritized over name.bash.

echo "This is the expected file to load."

help_me() { :; }
