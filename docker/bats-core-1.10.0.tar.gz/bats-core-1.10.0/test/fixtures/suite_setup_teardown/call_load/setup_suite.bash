setup_suite() {
  load test_helper
}
