setup_suite() {
  call-to-undefined-command
}
