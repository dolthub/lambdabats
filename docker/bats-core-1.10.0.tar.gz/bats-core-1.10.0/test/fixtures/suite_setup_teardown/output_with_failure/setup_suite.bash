setup_suite() {
  echo setup_suite
  false
}

teardown_suite() {
  echo teardown_suite
}
